// import { Tabs } from 'expo-router';
// import React from 'react';

// export default function TabLayout() {
//   return (
//     <Tabs>
//       <Tabs.Screen
//         name="EventList" // 👈 must match the file in (tabs)/EventList.tsx
//         options={{
//           tabBarLabel: 'Događaji', // 👈 this is the label text you want
//         }}
//       />
//       <Tabs.Screen
//         name="Profile"
//         options={{
//           tabBarLabel: 'Profil',
//         }}
//       />
//       {/* Add more screens as needed */}
//     </Tabs>
//   );
// }