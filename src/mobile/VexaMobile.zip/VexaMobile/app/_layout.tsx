import { Drawer } from 'expo-router/drawer';
import CustomDrawerContent from '../components/CustomDrawerContent';
import React from 'react';
import { HeaderShownContext } from '@react-navigation/elements';
export default function Layout() {
  return (
    <Drawer
      drawerContent={(props) => <CustomDrawerContent {...props} />}
      screenOptions={{
        headerShown: false,
        headerStyle: { backgroundColor: '#000A25' },
        headerTintColor: '#fff',
        drawerActiveTintColor: '#f06',
        drawerInactiveTintColor: '#ccc',
        
      }}
      >
      <Drawer.Screen
        name="(tabs)"
        options={{drawerLabel: 'Pocetna'}}
      >
      </Drawer.Screen>
      <Drawer.Screen 
        name="Login"
        options={{drawerLabel:'Login'}}
/>  
      <Drawer.Screen
        name="EventList"
        options={{drawerLabel:'Dogadjaji'}}
      >

      </Drawer.Screen>
      <Drawer.Screen
        name="PrikazPrijavljenihDogadjaja"
        options={{drawerLabel:'Moji dogadjaji'}}
      >

      </Drawer.Screen>
    </Drawer>
  );
}